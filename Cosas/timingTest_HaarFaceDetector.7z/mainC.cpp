//#define CV_NO_BACKWARD_COMPATIBILITY

#include "cv.h"
#include "highgui.h"

#include <iostream>
//#include <cstdio>
#include <vector>

using namespace std;
//using namespace cv;



// Decide if you will test the C interface or the C++ interface of OpenCV.
//#define TEST_CPP_INTERFACE



#ifdef TEST_CPP_INTERFACE
	typedef cv::CascadeClassifier CASCADE_TYPE;
#else
	typedef CvHaarClassifierCascade* CASCADE_TYPE;
	static CvMemStorage* storage = 0;
#endif


// Search for objects such as faces in the image using the given parameters,
// storing the multiple CvRects into 'objects'.
// Can use Haar cascades or LBP cascades for Face Detection, or even eye, mouth, or car detection.
void detectObjectsCustom(IplImage *img, CASCADE_TYPE cascade, float scale, vector<CvRect> &objects, int flags, CvSize minFeatureSize, float searchScaleFactor, int minNeighbors)
{
	IplImage *gray = 0;		// Assume it's not used, so it's not freed.
	IplImage *smallImg = 0;	// Assume it's not used, so it's not freed.
	IplImage *inputImg = img;	// Use the original image by default.
	double t;
	t = (double)cvGetTickCount();	// record the timing.

	// If the input image is color, convert it from color to greyscale.
	if (img->nChannels >= 3)
	{
		gray = cvCreateImage( cvGetSize(img), 8, 1 );
		cvCvtColor( img, gray, CV_BGR2GRAY );
		inputImg = gray;	// use this new image.
	}

	// Possibly shrink the image, to run faster.
	if (scale < 0.9999f || scale > 1.0001f)
	{
		int smallWidth = cvRound(img->width/scale);
		int smallHeight = cvRound(img->height/scale);
		smallImg = cvCreateImage(cvSize(smallWidth, smallHeight), 8, 1);
		cvResize( inputImg, smallImg, CV_INTER_LINEAR );
		inputImg = smallImg;	// use this new image.
	}

	// Standardize the brightness and contrast, so that dark images look better.
	cvEqualizeHist( inputImg, inputImg );

#ifdef TEST_CPP_INTERFACE
	// Get a new OpenCV 2.0 C++ style image that references the same IplImage.
	cv::Mat img2(inputImg);

	// Detect objects in the small greyscale image.
	vector<cv::Rect> objectsCPP;
	cascade.detectMultiScale( img2, objectsCPP, searchScaleFactor, minNeighbors, flags, minFeatureSize );

	// Resize the results if the image was temporarily scaled smaller
	if (smallImg) {
		objects.clear();
		for (int i = 0; i < objectsCPP.size(); i++ )
		{
			CvRect r;
			r.x = cvRound(objectsCPP[i].x * scale);
			r.y = cvRound(objectsCPP[i].y * scale);
			r.width = cvRound(objectsCPP[i].width * scale);
			r.height = cvRound(objectsCPP[i].height * scale);
			objects.push_back(r);
		}
	}
#else
	// Use the traditional C interface for detection.

	cvClearMemStorage( storage );

	// Detect objects in the small greyscale image.
	CvSeq* objectsSeq = cvHaarDetectObjects( inputImg, cascade, storage,
											searchScaleFactor, minNeighbors, 0
											//|CV_HAAR_FIND_BIGGEST_OBJECT
											//|CV_HAAR_DO_ROUGH_SEARCH
											|CV_HAAR_DO_CANNY_PRUNING
											//|CV_HAAR_SCALE_IMAGE
											//|flags
											,
											minFeatureSize );

	// Create a std::vector of CvRect structures from the sequence.
	objects.clear();
	for(int i = 0; i < (objectsSeq ? objectsSeq->total : 0); i++ )
	{
		CvRect* r = (CvRect*)cvGetSeqElem( objectsSeq, i );

		// Resize the results if the image was temporarily scaled smaller
		if (smallImg) {
			r->x = cvRound(r->x * scale);
			r->y = cvRound(r->y * scale);
			r->width = cvRound(r->width * scale);
			r->height = cvRound(r->height * scale);
		}

		objects.push_back(*r);
	}
#endif

	t = (double)cvGetTickCount() - t;
	cout << "[Detected " << objects.size() << " objects in " << cvRound(t/((double)cvGetTickFrequency()*1000.0)) << " milliseconds]" << endl;

	// Free the C resources (but not the C++ resources).
	if (gray)
		cvReleaseImage(&gray);
	if (smallImg)
		cvReleaseImage(&smallImg);
}

// Search for many objects in the image, such as all the faces,
// storing the results into 'objects' using the C style CvRect.
// Can use Haar cascades or LBP cascades for Face Detection, or even eye, mouth, or car detection.
// For Haar detectors, detectLargestObject() should be faster than detectManyObjects().
void detectManyObjects( IplImage *img, CASCADE_TYPE cascade, float scale, vector<CvRect> &objects)
{
	// Search for many objects in the one image.
	int flags = CV_HAAR_SCALE_IMAGE;
	// Smallest object size.
	CvSize minFeatureSize = cvSize(20, 20);
	// How detailed should the search be. Must be larger than 1.0.
	float searchScaleFactor = 1.1f;
	// How much the detections should be filtered out. This should depend on how bad false detections are to your system.
	// minNeighbors=2 means lots of good+bad detections, and minNeighbors=6 means only good detections are given but some are missed.
	int minNeighbors = 4;

	// Perform Object or Face Detection, looking for many objects in the one image.
	detectObjectsCustom(img, cascade, scale, objects, flags, minFeatureSize, searchScaleFactor, minNeighbors);
}

// Search for just a single object in the image, such as the largest face.
// storing the result into 'largestObject' using the C-style CvRect.
// Can use Haar cascades or LBP cascades for Face Detection, or even eye, mouth, or car detection.
// For Haar detectors, detectLargestObject() should be faster than detectManyObjects().
void detectLargestObject( IplImage *img, CASCADE_TYPE cascade, float scale, CvRect &largestObject)
{
	// Only search for just 1 object (the biggest in the image).
	int flags = CV_HAAR_FIND_BIGGEST_OBJECT | CV_HAAR_DO_ROUGH_SEARCH;
	// Smallest object size.
	CvSize minFeatureSize = cvSize(20, 20);
	// How detailed should the search be. Must be larger than 1.0.
	float searchScaleFactor = 1.1f;
	// How much the detections should be filtered out. This should depend on how bad false detections are to your system.
	// minNeighbors=2 means lots of good+bad detections, and minNeighbors=6 means only good detections are given but some are missed.
	int minNeighbors = 4;

	// Perform Object or Face Detection, looking for just 1 object (the biggest in the image).
	vector<CvRect> objects;
	detectObjectsCustom(img, cascade, scale, objects, flags, minFeatureSize, searchScaleFactor, minNeighbors);
	if (objects.size() > 0) {
		// Return the only detected object.
		largestObject = (CvRect)objects.at(0);
	}
	else
	{
		// Return an invalid rect.
		largestObject = cvRect(-1,-1,-1,-1);
	}
}


// Search for frontal faces in the image, drawing a rect or circle on the image
// and storing the rects into 'faces'.
// Can use Haar cascades or LBP cascades for Face Detection.
void detectAndDrawFaces( IplImage *imgIn, IplImage *imgOut, CASCADE_TYPE cascade, float scale, vector<CvRect>& faces, CvScalar color, bool showRect)
{
	int thickness = 2;

	// Just search for a single face.
	//CvRect rect;
	//detectLargestObject( img, cascade, scale, rect );
	//CvRect *r = &rect;

	// Do face detection
	detectManyObjects( imgIn, cascade, scale, faces );

	// Loop through each of the detected faces, to display them.
	for( vector<CvRect>::const_iterator r = faces.begin(); r != faces.end(); r++ )
	{
		if (showRect)
		{
			// Render a rectangle
			CvPoint topleft, bottomright;
			topleft.x = r->x;
			topleft.y = r->y;
			bottomright.x = r->x + r->width - 1;
			bottomright.y = r->y + r->height - 1;
			cvRectangle( imgOut, topleft, bottomright, color, thickness, CV_AA);	// Draw anti-aliased lines
		}
		else
		{
			// Render a circle
			CvPoint center;
			int radius;
			center.x = r->x + cvRound(r->width/2.0f);
			center.y = r->y + cvRound(r->height/2.0f);
			radius = cvRound(r->width/2.0f);
			cvCircle( imgOut, center, radius, color, thickness, CV_AA);	// Draw anti-aliased circles
		}
	}  
}


int main(int argc, char *argv[])
{
	cout << "Haar and LBP Face Detector, by Shervin Emami (www.shervinemami.info)" << endl;
	cout << "This program was compiled on " __TIMESTAMP__ << endl;
	cout << "OpenCV version: " << CV_VERSION << endl;

	// For timing tests, can run multiple times and average the results.
	int NUMBER_OF_TEST_RUNS = 5;

	// How much to shrink the image before face detection.
	// A value upto 1.3f will make it run faster and detect faces almost as reliably.
	float scale = 1.3f;

	char *imageFile;
	if (argc <= 1)
		imageFile = "f1.jpg";
	else
		imageFile = argv[1];

	char* cascadeFileHaar = "haarcascade_frontalface_alt.xml";
//	string cascadeFileLBP = "lbpcascade_frontalface.xml";

	CASCADE_TYPE cascadeHaar;
	//CASCADE_TYPE *cascadeLBP;
	vector<CvRect> faces;
	double t;

	// Load the Haar Face Detection Cascade Classifier.
	cout << "Loading Haar classifier cascade: " << cascadeFileHaar << endl;
//	if( !cascadeHaar.load( cascadeFileHaar ) )
#ifdef TEST_CPP_INTERFACE
	cout << "Testing the C++ interface" << endl;
	if( !cascadeHaar.load( cascadeFileHaar ) )
#else
	cout << "Testing the C interface" << endl;
    storage = cvCreateMemStorage(0);
	if( ! (cascadeHaar = (CvHaarClassifierCascade*)cvLoad(cascadeFileHaar, 0,0,0) ) )
#endif
	{
		cerr << "ERROR: Could not load Haar classifier cascade: " << cascadeFileHaar << endl;
		return -1;
	}
/*	// Load the Haar Face Detection Cascade Classifier.
	cout << "Loading LBP classifier cascade: " << cascadeFileLBP << endl;
	if( !cascadeLBP.load( cascadeFileLBP ) )
	{
		cerr << "ERROR: Could not load LBP classifier cascade: " << cascadeFileLBP << endl;
		return -1;
	}
*/

	// Create a GUI Window
	char *title = "FaceDetector";
	cvNamedWindow( title, 1 );

	// Load the image file.
	cout << "Loading image file: " << imageFile << endl;
	IplImage *imageOriginal = cvLoadImage( imageFile, 1 );
	if( !imageOriginal ) {
		cerr << "ERROR: couldnt load image file: " << imageFile << endl;
		return -1;
	}
	IplImage *imageOut = cvCloneImage(imageOriginal);

	// Show the Haar detected faces as blue circles.
	cout << endl;
	cout << "Detecting faces in the image using the Haar-detector ..." << endl;
	t = (double)cvGetTickCount();	// record the timing.
	for (int i=0; i<NUMBER_OF_TEST_RUNS; i++) {
		detectAndDrawFaces( imageOriginal, imageOut, cascadeHaar, scale, faces, CV_RGB(0,0,255), false );
	}
	t = (double)cvGetTickCount() - t;
	cout << "Haar-detector took an average of " << cvRound(t/((double)cvGetTickFrequency()*1000.0*NUMBER_OF_TEST_RUNS)) << " milliseconds." << endl;
	cout << "Haar-detector found " << faces.size() << " faces in the image (blue circles)." << endl;

/*	// Show the LBP detected faces as green squares.
	cout << endl;
	cout << "Detecting faces in the image using the LBP-detector ..." << endl;
	t = (double)cvGetTickCount();	// record the timing.
	for (int i=0; i<NUMBER_OF_TEST_RUNS; i++) {
		detectAndDrawFaces( imageOriginal, imageOut, cascadeLBP, scale, faces, CV_RGB(0,255,0), true );
	}
	t = (double)cvGetTickCount() - t;
	cout << "LBP-detector took an average of " << cvRound(t/((double)cvGetTickFrequency()*1000.0*NUMBER_OF_TEST_RUNS)) << " milliseconds." << endl;
	cout << "LBP-detector found " << faces.size() << " faces in the image (green squares)." << endl;
*/

	// Display the data
	cvShowImage( title, imageOut );
	// Give some time for OpenCV and the OS to display the data on the screen. cvWaitKey is necessary!
	cout << "Press any key in the window to continue ..." << endl;
	cvWaitKey(0);

	// Close the GUI window.
	cvDestroyWindow(title);
	cvReleaseImage(&imageOriginal);
	cvReleaseImage(&imageOut);

	return 0;
}